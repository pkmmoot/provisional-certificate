'use server';

import { verifyDocument, VerifyDocumentInput } from '@/ai/flows/document-verification';

export async function verifyDocumentAction(input: VerifyDocumentInput) {
  try {
    const result = await verifyDocument(input);
    return result;
  } catch (error) {
    console.error('Error verifying document:', error);
    return {
      isValid: false,
      reason: 'An unexpected error occurred during verification.',
    };
  }
}
