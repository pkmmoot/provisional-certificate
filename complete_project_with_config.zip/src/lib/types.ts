import * as z from 'zod';

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const ACCEPTED_DOC_TYPES = ['image/jpeg', 'image/png', 'application/pdf'];
const ACCEPTED_IMAGE_TYPES = ['image/jpeg', 'image/png'];

const fileSchema = (types: string[]) =>
  z
    .any()
    .refine((file): file is File => file instanceof File, 'File is required.')
    .refine((file) => file?.size <= MAX_FILE_SIZE, `Max file size is 5MB.`)
    .refine(
      (file) => types.includes(file?.type),
      `Only ${types.map((t) => t.split('/')[1]).join(', ')} formats are supported.`
    ).nullable().optional();


export const formSchema = z.object({
  studentName: z.string().min(2, { message: "Student's name is required." }),
  fatherName: z.string().min(2, { message: "Father's name is required." }),
  mobileNumber: z.string().regex(/^\d{10}$/, { message: 'Must be a valid 10-digit mobile number.' }),
  email: z.string().email({ message: 'Must be a valid email address.' }),
  residentialAddress: z.string().min(10, { message: 'Residential address is required.' }),
  aadharNumber: z.string().regex(/^\d{12}$/, { message: 'Must be a valid 12-digit Aadhar number.' }),
  panNumber: z.string().regex(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/, { message: 'Must be a valid PAN number.' }),
  rollNumber: z.string().min(1, { message: 'Roll number is required.' }),
  registrationNumber: z.string().min(1, { message: 'Registration number is required.' }),
  admissionDate: z.date({ required_error: 'Date of admission is required.' }),
  academicSession: z.string().min(1, { message: 'Academic session is required.' }),
  declarationDate: z.date({ required_error: 'Date of declaration is required.' }),
  marksObtained: z.string().min(1, { message: 'Marks obtained are required.' }),
  rank: z.string().min(1, { message: 'Rank is required.' }),
  division: z.enum(['1st Division', '2nd Division', '3rd Division', 'Simple Pass']),
  photo: fileSchema(ACCEPTED_IMAGE_TYPES).refine(file => file, 'Photo is required.'),
  marksheet: fileSchema(ACCEPTED_DOC_TYPES).refine(file => file, 'Marksheet is required.'),
  registrationCard: fileSchema(ACCEPTED_DOC_TYPES).refine(file => file, 'Registration card is required.'),
  admitCard: fileSchema(ACCEPTED_DOC_TYPES).refine(file => file, 'Admit card is required.'),
  paymentSlip: fileSchema(ACCEPTED_DOC_TYPES).refine(file => file, 'Payment slip is required.'),
  declaration: z.boolean().refine((val) => val === true, {
    message: 'You must agree to the declaration.',
  }),
});

export type FormValues = z.infer<typeof formSchema>;

export type StoredFile = {
  name: string;
  dataUrl: string;
};
