import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { format } from 'date-fns';
import type { StoredFile } from './types';

// Extend the jsPDF type definitions for autoTable
declare module 'jspdf' {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

export const generatePdf = (submission: any) => {
  const doc = new jsPDF();

  // College Header
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('Tinsukia Law College', doc.internal.pageSize.getWidth() / 2, 20, { align: 'center' });
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.text('Provisional Certificate Application', doc.internal.pageSize.getWidth() / 2, 28, { align: 'center' });
  doc.setLineWidth(0.5);
  doc.line(20, 32, doc.internal.pageSize.getWidth() - 20, 32);

  // Submission Details
  doc.setFontSize(10);
  doc.text(`Submission ID: ${submission.id}`, 20, 40);
  doc.text(`Submission Date: ${new Date(submission.id).toLocaleString()}`, doc.internal.pageSize.getWidth() - 20, 40, { align: 'right' });

  // Add a little space
  let yPos = 50;

  // Personal Details
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('Personal Information', 20, yPos);
  yPos += 5;
  doc.autoTable({
    startY: yPos,
    head: [['Field', 'Value']],
    body: [
      ['Student Name', submission.studentName],
      ["Father's Name", submission.fatherName],
      ['Mobile Number', submission.mobileNumber],
      ['Email ID', submission.email],
      ['Residential Address', submission.residentialAddress],
      ['Aadhar Number', submission.aadharNumber],
      ['PAN Number', submission.panNumber],
    ],
    theme: 'striped',
    headStyles: { fillColor: [139, 0, 0] },
  });
  yPos = (doc as any).lastAutoTable.finalY + 15;

  // Academic Details
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('Academic Information', 20, yPos);
  yPos += 5;
  doc.autoTable({
    startY: yPos,
    head: [['Field', 'Value']],
    body: [
      ['Roll Number', submission.rollNumber],
      ['Registration Number', submission.registrationNumber],
      ['Date of Admission', submission.admissionDate ? format(new Date(submission.admissionDate), 'PPP') : 'N/A'],
      ['Academic Session', submission.academicSession],
      ['Date of Declaration', submission.declarationDate ? format(new Date(submission.declarationDate), 'PPP') : 'N/A'],
      ['Marks Obtained', submission.marksObtained],
      ['Rank', submission.rank],
      ['Division', submission.division],
    ],
    theme: 'striped',
    headStyles: { fillColor: [139, 0, 0] },
  });
  yPos = (doc as any).lastAutoTable.finalY + 15;
  
  // Uploaded Documents
  const uploadedFiles = [
    submission.photo,
    submission.marksheet,
    submission.registrationCard,
    submission.admitCard,
    submission.paymentSlip,
  ]
  .filter((file): file is StoredFile => !!file)
  .map(file => [file.name]);

  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('Uploaded Documents', 20, yPos);
  yPos += 5;
  doc.autoTable({
    startY: yPos,
    head: [['File Name']],
    body: uploadedFiles.length > 0 ? uploadedFiles : [['No documents were uploaded']],
    theme: 'grid',
    headStyles: { fillColor: [139, 0, 0] },
  });
  yPos = (doc as any).lastAutoTable.finalY + 15;
  
  // Declaration
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Declaration', 20, yPos);
  yPos += 7;
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('I hereby declare that all information provided is true and all uploaded documents are authentic.', 20, yPos);


  // Save the PDF
  doc.save(`submission-${submission.studentName}-${submission.rollNumber}.pdf`);
};
