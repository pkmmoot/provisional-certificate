'use client';

import { useState, useMemo } from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { TLCLogo } from '@/components/application/TLCLogo';
import { Stepper } from '@/components/application/Stepper';
import Step1PersonalInfo from '@/components/application/Step1_PersonalInfo';
import Step2AcademicDetails from '@/components/application/Step2_AcademicDetails';
import Step3DocumentUpload from '@/components/application/Step3_DocumentUpload';
import Step4Review from '@/components/application/Step4_Review';
import Step5Success from '@/components/application/Step5_Success';
import AdminSection from '@/components/application/AdminSection';
import type { FormValues } from '@/lib/types';
import { formSchema } from '@/lib/types';
import { Card } from '@/components/ui/card';
import { fileToDataUrl } from '@/lib/utils';

export default function Home() {
  const [currentStep, setCurrentStep] = useState(0);

  const steps = useMemo(() => [
    { title: 'Personal Info', fields: ['studentName', 'fatherName', 'mobileNumber', 'email', 'residentialAddress', 'aadharNumber', 'panNumber'] },
    { title: 'Academic Details', fields: ['rollNumber', 'registrationNumber', 'admissionDate', 'academicSession', 'declarationDate', 'marksObtained', 'rank', 'division'] },
    { title: 'Documents', fields: ['photo', 'marksheet', 'registrationCard', 'admitCard', 'paymentSlip'] },
    { title: 'Review & Submit', fields: ['declaration'] },
  ], []);

  const methods = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    mode: 'onChange',
    defaultValues: {
      studentName: '',
      fatherName: '',
      mobileNumber: '',
      email: '',
      residentialAddress: '',
      aadharNumber: '',
      panNumber: '',
      rollNumber: '',
      registrationNumber: '',
      admissionDate: undefined,
      academicSession: '',
      declarationDate: undefined,
      marksObtained: '',
      rank: '',
      division: '1st Division',
      photo: undefined,
      marksheet: undefined,
      registrationCard: undefined,
      admitCard: undefined,
      paymentSlip: undefined,
      declaration: false,
    },
  });

  const { trigger, handleSubmit } = methods;

  const handleNext = async () => {
    const fields = steps[currentStep].fields;
    const output = await trigger(fields as any, { shouldFocus: true });
    if (!output) return;
    setCurrentStep((prev) => prev + 1);
  };

  const handlePrev = () => {
    setCurrentStep((prev) => prev - 1);
  };

  const onSubmit = async (data: FormValues) => {
    console.log('Form Submitted', data);
    try {
      const submissions = JSON.parse(localStorage.getItem('submissions') || '[]');
      
      const newSubmission = {
        id: new Date().toISOString(),
        ...data,
        photo: data.photo ? { name: data.photo.name, dataUrl: await fileToDataUrl(data.photo) } : undefined,
        marksheet: data.marksheet ? { name: data.marksheet.name, dataUrl: await fileToDataUrl(data.marksheet) } : undefined,
        registrationCard: data.registrationCard ? { name: data.registrationCard.name, dataUrl: await fileToDataUrl(data.registrationCard) } : undefined,
        admitCard: data.admitCard ? { name: data.admitCard.name, dataUrl: await fileToDataUrl(data.admitCard) } : undefined,
        paymentSlip: data.paymentSlip ? { name: data.paymentSlip.name, dataUrl: await fileToDataUrl(data.paymentSlip) } : undefined,
      };

      submissions.push(newSubmission);
      localStorage.setItem('submissions', JSON.stringify(submissions));
    } catch (error) {
      console.error("Could not save submission to local storage", error);
    }
    setCurrentStep((prev) => prev + 1);
  };

  return (
    <FormProvider {...methods}>
      <main className="min-h-screen bg-background w-full flex flex-col items-center p-4 sm:p-6 md:p-8">
        <div className="w-full max-w-4xl">
          <header className="flex flex-col sm:flex-row items-center gap-4 mb-8">
            <TLCLogo className="w-20 h-20 text-primary" />
            <div className="text-center sm:text-left">
              <h1 className="text-3xl md:text-4xl font-headline font-bold text-primary">
                Tinsukia Law College
              </h1>
              <p className="text-lg text-foreground/80 font-headline">
                Provisional Certificate Application
              </p>
            </div>
          </header>

          <Card className="p-6 md:p-8">
            {currentStep <= steps.length -1 && <Stepper currentStep={currentStep} steps={steps.map(s => s.title)} />}
            
            <form onSubmit={handleSubmit(onSubmit)} className="mt-8">
              {currentStep === 0 && <Step1PersonalInfo handleNext={handleNext} />}
              {currentStep === 1 && <Step2AcademicDetails handleNext={handleNext} handlePrev={handlePrev} />}
              {currentStep === 2 && <Step3DocumentUpload handleNext={handleNext} handlePrev={handlePrev} />}
              {currentStep === 3 && <Step4Review handlePrev={handlePrev} />}
              {currentStep === 4 && <Step5Success />}
            </form>
          </Card>
        </div>
        <AdminSection />
      </main>
    </FormProvider>
  );
}
