'use server';

/**
 * @fileOverview Document verification flow for validating uploaded documents against college records.
 *
 * - verifyDocument - A function that handles the document verification process.
 * - VerifyDocumentInput - The input type for the verifyDocument function.
 * - VerifyDocumentOutput - The return type for the verifyDocument function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const VerifyDocumentInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      "A photo of the document to verify, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  documentType: z.string().describe('The type of document being verified (e.g., Marksheet, Registration Card).'),
  studentName: z.string().describe('The name of the student.'),
  rollNumber: z.string().describe('The roll number of the student.'),
});
export type VerifyDocumentInput = z.infer<typeof VerifyDocumentInputSchema>;

const VerifyDocumentOutputSchema = z.object({
  isValid: z.boolean().describe('Whether the document is valid or not.'),
  reason: z.string().describe('The reason for the document being invalid, if applicable.'),
});
export type VerifyDocumentOutput = z.infer<typeof VerifyDocumentOutputSchema>;

export async function verifyDocument(input: VerifyDocumentInput): Promise<VerifyDocumentOutput> {
  return verifyDocumentFlow(input);
}

const verifyDocumentPrompt = ai.definePrompt({
  name: 'verifyDocumentPrompt',
  input: {schema: VerifyDocumentInputSchema},
  output: {schema: VerifyDocumentOutputSchema},
  prompt: `You are an expert document verification specialist at Tinsukia Law College.

You will use the provided document image, document type, student name and roll number to determine if the document is valid.

Here's the information:
Document Type: {{{documentType}}}
Student Name: {{{studentName}}}
Roll Number: {{{rollNumber}}}
Document Image: {{media url=photoDataUri}}

Based on this information, determine if the document is valid and provide a reason if it is not.
Set the isValid field to true if the document is valid, and false if it is not.  If it is not, include a reason why.
`,
});

const verifyDocumentFlow = ai.defineFlow(
  {
    name: 'verifyDocumentFlow',
    inputSchema: VerifyDocumentInputSchema,
    outputSchema: VerifyDocumentOutputSchema,
  },
  async input => {
    const {output} = await verifyDocumentPrompt(input);
    return output!;
  }
);
