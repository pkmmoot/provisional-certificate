import { config } from 'dotenv';
config();

import '@/ai/flows/document-verification.ts';