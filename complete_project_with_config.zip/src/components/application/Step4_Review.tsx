'use client';

import { useState } from 'react';
import { useFormContext } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ArrowLeft, Send, User, FileText, CheckCircle, XCircle, AlertCircle, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { format } from 'date-fns';
import { verifyDocumentAction } from '@/lib/actions';
import { useToast } from '@/hooks/use-toast';
import type { FormValues } from '@/lib/types';


interface Props {
  handlePrev: () => void;
}

type VerificationStatus = 'idle' | 'loading' | 'success' | 'error';

const ReviewItem = ({ label, value }: { label: string; value: string | undefined }) => (
  <div>
    <p className="text-sm text-muted-foreground">{label}</p>
    <p className="font-medium">{value || 'N/A'}</p>
  </div>
);

const FileItem = ({ file }: { file: File | undefined | null }) => (
  <div className="flex items-center space-x-2 text-sm text-foreground">
    <FileText className="h-4 w-4 text-primary" />
    <span>{file?.name || 'Not uploaded'}</span>
  </div>
);

export default function Step4Review({ handlePrev }: Props) {
  const { control, getValues } = useFormContext<FormValues>();
  const { toast } = useToast();
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus>('idle');
  const [verificationResult, setVerificationResult] = useState<{ isValid: boolean; reason: string } | null>(null);

  const values = getValues();

  const handleVerification = async () => {
    setVerificationStatus('loading');
    const { studentName, rollNumber, marksheet } = getValues();
    
    if (!marksheet) {
      toast({
        variant: 'destructive',
        title: 'Verification Failed',
        description: 'Please upload your marksheet before verifying.',
      });
      setVerificationStatus('error');
      setVerificationResult({ isValid: false, reason: 'Marksheet not uploaded.' });
      return;
    }

    const reader = new FileReader();
    reader.readAsDataURL(marksheet);
    reader.onload = async () => {
      const photoDataUri = reader.result as string;
      try {
        const result = await verifyDocumentAction({
          studentName,
          rollNumber,
          documentType: 'Marksheet',
          photoDataUri,
        });
        setVerificationResult(result);
        setVerificationStatus(result.isValid ? 'success' : 'error');
        toast({
          title: result.isValid ? 'Verification Successful' : 'Verification Failed',
          description: result.isValid ? 'Your marksheet has been successfully verified.' : result.reason,
          variant: result.isValid ? 'default' : 'destructive',
        });
      } catch (e) {
        setVerificationStatus('error');
        setVerificationResult({ isValid: false, reason: 'An unknown error occurred.' });
        toast({
          variant: 'destructive',
          title: 'Verification Error',
          description: 'Could not connect to the verification service.',
        });
      }
    };
    reader.onerror = () => {
       setVerificationStatus('error');
       setVerificationResult({ isValid: false, reason: 'Could not read the file.' });
       toast({
        variant: 'destructive',
        title: 'File Read Error',
        description: 'There was an error processing your marksheet file.',
      });
    }
  };


  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-headline font-semibold text-primary">Review & Submit</h2>
        <p className="text-muted-foreground mt-1">
          Please review all information before submitting your application.
        </p>
      </div>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-headline text-xl text-primary"><User />Personal Information</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ReviewItem label="Student Name" value={values.studentName} />
            <ReviewItem label="Father's Name" value={values.fatherName} />
            <ReviewItem label="Mobile Number" value={values.mobileNumber} />
            <ReviewItem label="Email ID" value={values.email} />
            <ReviewItem label="Residential Address" value={values.residentialAddress} />
            <ReviewItem label="Aadhar Number" value={values.aadharNumber} />
            <ReviewItem label="PAN Number" value={values.panNumber} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-headline text-xl text-primary"><FileText />Academic Information</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <ReviewItem label="Roll Number" value={values.rollNumber} />
             <ReviewItem label="Registration Number" value={values.registrationNumber} />
             <ReviewItem label="Date of Admission" value={values.admissionDate ? format(values.admissionDate, 'PPP') : 'N/A'} />
             <ReviewItem label="Academic Session" value={values.academicSession} />
             <ReviewItem label="Date of Declaration" value={values.declarationDate ? format(values.declarationDate, 'PPP') : 'N/A'} />
             <ReviewItem label="Marks Obtained" value={values.marksObtained} />
             <ReviewItem label="Rank" value={values.rank} />
             <ReviewItem label="Division" value={values.division} />
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-headline text-xl text-primary"><FileText />Uploaded Documents</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <FileItem file={values.photo} />
            <FileItem file={values.marksheet} />
            <FileItem file={values.registrationCard} />
            <FileItem file={values.admitCard} />
            <FileItem file={values.paymentSlip} />
            <Separator className="my-4" />
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <Button type="button" onClick={handleVerification} disabled={verificationStatus === 'loading'}>
                {verificationStatus === 'loading' ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Verify Marksheet with AI
              </Button>
              {verificationStatus === 'success' && <div className="flex items-center gap-2 text-green-600"><CheckCircle /><span>Verified</span></div>}
              {verificationStatus === 'error' && <div className="flex items-center gap-2 text-red-600"><XCircle /><span>{verificationResult?.reason || 'Verification Failed'}</span></div>}
            </div>
          </CardContent>
        </Card>
      </div>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Application Review Process</AlertTitle>
        <AlertDescription>
          Your application will be reviewed by the college administration and verified against uploaded documents. This process takes 3-5 working days. You will be contacted via email/phone for collection.
        </AlertDescription>
      </Alert>

      <FormField
        control={control}
        name="declaration"
        render={({ field }) => (
          <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
            <FormControl>
              <Checkbox
                checked={field.value}
                onCheckedChange={field.onChange}
              />
            </FormControl>
            <div className="space-y-1 leading-none">
              <FormLabel>
                I hereby declare that all information provided is true, all uploaded documents are authentic, and I agree to the terms and conditions.
              </FormLabel>
              <FormMessage />
            </div>
          </FormItem>
        )}
      />

      <div className="flex justify-between mt-8">
        <Button type="button" variant="outline" onClick={handlePrev}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Previous Page
        </Button>
        <Button type="submit">
          Submit Application <Send className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
