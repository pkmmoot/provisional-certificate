'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, LogIn, LogOut, Download, FileText, Trash2, Edit, PlusCircle } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { generatePdf } from '@/lib/pdf';
import { downloadFile } from '@/lib/utils';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

export default function AdminSection() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submissions, setSubmissions] = useState<any[]>([]);

  const loadSubmissions = () => {
     try {
        const storedSubmissions = JSON.parse(localStorage.getItem('submissions') || '[]');
        setSubmissions(storedSubmissions.sort((a: any, b: any) => new Date(b.id).getTime() - new Date(a.id).getTime()));
      } catch (e) {
        console.error("Failed to parse submissions from localStorage", e);
        setSubmissions([]);
      }
  }

  useEffect(() => {
    if (isLoggedIn) {
      loadSubmissions();
    }
  }, [isLoggedIn]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'tskdusem06' && password === 'Tsklaw@1973') {
      setIsLoggedIn(true);
      setError('');
    } else {
      setError('Invalid username or password.');
    }
  };
  
  const handleLogout = () => {
    setIsLoggedIn(false);
    setUsername('');
    setPassword('');
  };

  const handleDownloadPdf = (submission: any) => {
    generatePdf(submission);
  };
  
  const handleDelete = (submissionId: string) => {
    const updatedSubmissions = submissions.filter(s => s.id !== submissionId);
    localStorage.setItem('submissions', JSON.stringify(updatedSubmissions));
    setSubmissions(updatedSubmissions);
  };

  const FileDownloadLink = ({ file, label }: { file: { name: string; dataUrl: string } | undefined, label: string }) => {
    if (!file) {
      return <li>{label}: Not Uploaded</li>;
    }
    return (
      <li className="flex items-center justify-between">
        <span>{label}: {file.name}</span>
        <Button variant="ghost" size="sm" onClick={() => downloadFile(file.dataUrl, file.name)}>
          <Download className="mr-2 h-4 w-4" />
          Download
        </Button>
      </li>
    );
  };

  return (
    <div className="w-full max-w-4xl mt-12">
      <Card className="bg-secondary/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-headline text-primary">
            <Shield />
            Admin Section
          </CardTitle>
          <CardDescription>
            For administrative use only. Submitted applications are displayed here.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!isLoggedIn ? (
            <form onSubmit={handleLogin} className="space-y-4 max-w-sm">
              <Input
                type="text"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              {error && <p className="text-sm text-destructive">{error}</p>}
              <Button type="submit"><LogIn className="mr-2 h-4 w-4" /> Login</Button>
            </form>
          ) : (
            <div>
              <div className="flex justify-between items-center mb-4">
                 <div className="flex items-center gap-4">
                    <h3 className="text-lg font-bold">Submitted Applications ({submissions.length})</h3>
                    <Button variant="outline" size="sm"><PlusCircle className="mr-2 h-4 w-4" /> Add New</Button>
                 </div>
                <Button variant="outline" size="sm" onClick={handleLogout}><LogOut className="mr-2 h-4 w-4" /> Logout</Button>
              </div>
              {submissions.length === 0 ? (
                <p className="text-muted-foreground">No submissions yet.</p>
              ) : (
                <Accordion type="single" collapsible className="w-full">
                  {submissions.map((sub) => (
                    <AccordionItem value={`item-${sub.id}`} key={sub.id}>
                      <AccordionTrigger>
                        <div className="flex justify-between w-full pr-4">
                           <span>{sub.studentName} - {sub.rollNumber}</span>
                           <span className="text-sm text-muted-foreground">{new Date(sub.id).toLocaleString()}</span>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-4 p-4 rounded-md bg-background">
                            <div className="flex justify-between items-center">
                               <h4 className="font-bold">Personal Details</h4>
                               <div className="flex items-center gap-2">
                                <Button size="sm" variant="outline"><Edit className="mr-2 h-4 w-4" /> Edit</Button>
                                 <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button size="sm" variant="destructive"><Trash2 className="mr-2 h-4 w-4" /> Delete</Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        This action cannot be undone. This will permanently delete the application for {sub.studentName}.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction onClick={() => handleDelete(sub.id)}>
                                        Continue
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                                <Button size="sm" onClick={() => handleDownloadPdf(sub)}>
                                  <Download className="mr-2 h-4 w-4" /> PDF
                                </Button>
                               </div>
                            </div>
                            <p><strong>Father's Name:</strong> {sub.fatherName}</p>
                            <p><strong>Contact:</strong> {sub.mobileNumber} / {sub.email}</p>
                            <p><strong>Address:</strong> {sub.residentialAddress}</p>
                            <p><strong>Aadhar:</strong> {sub.aadharNumber} | <strong>PAN:</strong> {sub.panNumber}</p>
                            <h4 className="font-bold mt-4">Academic Details</h4>
                            <p><strong>Registration No:</strong> {sub.registrationNumber}</p>
                            <p><strong>Admission Date:</strong> {new Date(sub.admissionDate).toLocaleDateString()}</p>
                            <p><strong>Session:</strong> {sub.academicSession}</p>
                            <p><strong>Declaration Date:</strong> {new Date(sub.declarationDate).toLocaleDateString()}</p>
                            <p><strong>Marks:</strong> {sub.marksObtained} | <strong>Rank:</strong> {sub.rank} | <strong>Division:</strong> {sub.division}</p>
                            <h4 className="font-bold mt-4">Uploaded Files</h4>
                            <ul className="list-inside space-y-2">
                                <FileDownloadLink file={sub.photo} label="Photo" />
                                <FileDownloadLink file={sub.marksheet} label="Marksheet" />
                                <FileDownloadLink file={sub.registrationCard} label="Registration Card" />
                                <FileDownloadLink file={sub.admitCard} label="Admit Card" />
                                <FileDownloadLink file={sub.paymentSlip} label="Payment Slip" />
                            </ul>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
