import { cn } from '@/lib/utils';
import { Check } from 'lucide-react';

interface StepperProps {
  currentStep: number;
  steps: string[];
}

export function Stepper({ currentStep, steps }: StepperProps) {
  return (
    <div className="flex justify-between items-center w-full mb-8">
      {steps.map((step, index) => {
        const isActive = index === currentStep;
        const isCompleted = index < currentStep;

        return (
          <div key={step} className={cn("flex-1 flex items-center gap-4", index > 0 && "justify-center", index === steps.length - 1 && "justify-end")}>
             {index > 0 && <div className={cn("h-px w-full", isCompleted ? 'bg-primary' : 'bg-border')} />}
            <div className="flex flex-col items-center gap-2">
              <div
                className={cn(
                  'w-8 h-8 rounded-full flex items-center justify-center transition-colors',
                  isCompleted ? 'bg-primary text-primary-foreground' : isActive ? 'bg-primary/20 border-2 border-primary text-primary' : 'bg-secondary text-secondary-foreground'
                )}
              >
                {isCompleted ? <Check className="w-5 h-5" /> : <span className="font-bold">{index + 1}</span>}
              </div>
              <p className={cn("text-sm text-center", isActive || isCompleted ? 'text-primary font-medium' : 'text-muted-foreground')}>
                {step}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
