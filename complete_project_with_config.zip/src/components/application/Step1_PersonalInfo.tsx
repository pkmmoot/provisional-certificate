'use client';

import { useFormContext } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { ArrowRight, ShieldCheck, User, Mail, Phone, Home, Fingerprint, ScanLine } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface Props {
  handleNext: () => void;
}

export default function Step1PersonalInfo({ handleNext }: Props) {
  const { control } = useFormContext();

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-headline font-semibold text-primary">Personal Information</h2>
        <p className="text-muted-foreground mt-1">
          Please provide your personal details as they appear on official documents.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormField
          control={control}
          name="studentName"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Student Name *</FormLabel>
              <FormControl>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="e.g., John Doe" {...field} className="pl-10" autoComplete="off" />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={control}
          name="fatherName"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Father's Name *</FormLabel>
              <FormControl>
                <div className="relative">
                   <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="e.g., Richard Doe" {...field} className="pl-10" autoComplete="off" />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={control}
          name="mobileNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Mobile Number *</FormLabel>
              <FormControl>
                <div className="relative">
                   <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input type="tel" placeholder="e.g., 9876543210" {...field} className="pl-10" autoComplete="off" />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email ID *</FormLabel>
              <FormControl>
                 <div className="relative">
                   <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input type="email" placeholder="e.g., john.doe@example.com" {...field} className="pl-10" autoComplete="off" />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={control}
          name="residentialAddress"
          render={({ field }) => (
            <FormItem className="md:col-span-2">
              <FormLabel>Residential Address *</FormLabel>
              <FormControl>
                 <div className="relative">
                   <Home className="absolute left-3 top-4 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Your full residential address" {...field} className="pl-10" autoComplete="off" />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      <div>
        <h3 className="text-xl font-headline font-semibold text-primary">Government ID Details</h3>
        <Alert className="mt-2 bg-primary/5 border-primary/20">
          <ShieldCheck className="h-4 w-4 text-primary" />
          <AlertTitle className="text-primary/90">Important Security Notice</AlertTitle>
          <AlertDescription className="text-foreground/70">
            Your Aadhar and PAN details are encrypted and used only for certificate verification purposes.
          </AlertDescription>
        </Alert>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormField
          control={control}
          name="aadharNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Aadhar Number *</FormLabel>
              <FormControl>
                 <div className="relative">
                   <Fingerprint className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="12-digit Aadhar number" {...field} className="pl-10" autoComplete="off" />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={control}
          name="panNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel>PAN Number *</FormLabel>
              <FormControl>
                <div className="relative">
                   <ScanLine className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="10-character PAN number" {...field} className="pl-10" autoComplete="off" />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      <div className="flex justify-end mt-8">
        <Button type="button" onClick={handleNext}>
          Next Page <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
