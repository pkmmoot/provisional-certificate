'use client';

import { useFormContext } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { FormField, FormItem, FormLabel, FormMessage, FormControl } from '@/components/ui/form';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ArrowLeft, ArrowRight, UploadCloud, FileText, X } from 'lucide-react';
import { Card } from '@/components/ui/card';

interface Props {
  handleNext: () => void;
  handlePrev: () => void;
}

const FileInput = ({ field, label, accept }: { field: any, label: string, accept: string }) => {
  return (
    <Card className="p-4 bg-secondary/30 border-dashed">
      <FormLabel>{label}</FormLabel>
      <div className="flex items-center space-x-4 mt-2">
        <div className="flex-1">
          <FormControl>
            <Input
              type="file"
              accept={accept}
              onChange={(e) => field.onChange(e.target.files?.[0])}
              className="block w-full text-sm text-slate-500
                file:mr-4 file:py-2 file:px-4
                file:rounded-full file:border-0
                file:text-sm file:font-semibold
                file:bg-primary/10 file:text-primary
                hover:file:bg-primary/20"
            />
          </FormControl>
        </div>
        {field.value && (
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <FileText className="h-4 w-4" />
            <span className="truncate max-w-[150px]">{field.value.name}</span>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={() => field.onChange(null)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>
      <FormMessage className="mt-2" />
    </Card>
  );
};

export default function Step3DocumentUpload({ handleNext, handlePrev }: Props) {
  const { control } = useFormContext();

  const documentFields = [
    { name: 'photo', label: 'Upload Photo (Passport size, JPG/PNG)*', accept: 'image/jpeg,image/png' },
    { name: 'marksheet', label: 'Upload Marksheet (Latest semester, PDF/JPG/PNG)*', accept: 'application/pdf,image/jpeg,image/png' },
    { name: 'registrationCard', label: 'Registration Card (University, PDF/JPG/PNG)*', accept: 'application/pdf,image/jpeg,image/png' },
    { name: 'admitCard', label: 'Admit Card (Final semester, PDF/JPG/PNG)*', accept: 'application/pdf,image/jpeg,image/png' },
    { name: 'paymentSlip', label: 'Payment Slip (Fee receipt, PDF/JPG/PNG)*', accept: 'application/pdf,image/jpeg,image/png' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-headline font-semibold text-primary">Document Upload</h2>
        <p className="text-muted-foreground mt-1">
          Upload required documents for verification.
        </p>
      </div>

      <Alert className="bg-primary/5 border-primary/20">
        <UploadCloud className="h-4 w-4 text-primary" />
        <AlertTitle className="text-primary/90">Upload Requirements</AlertTitle>
        <AlertDescription className="text-foreground/70">
          <ul className="list-disc pl-5 mt-1 space-y-1">
            <li>Photo must be JPG or PNG. Other documents can be PDF, JPG, or PNG.</li>
            <li>Maximum file size is 5MB for each document.</li>
            <li>Images should be clear and readable.</li>
            <li>All documents are required for processing.</li>
          </ul>
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-1 gap-6">
        {documentFields.map(({ name, label, accept }) => (
          <FormField
            key={name}
            control={control}
            name={name}
            render={({ field }) => <FileInput field={field} label={label} accept={accept} />}
          />
        ))}
      </div>

      <div className="flex justify-between mt-8">
        <Button type="button" variant="outline" onClick={handlePrev}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Previous Page
        </Button>
        <Button type="button" onClick={handleNext}>
          Next Page <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
