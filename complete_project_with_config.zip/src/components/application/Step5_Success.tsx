'use client';

import { CheckCircle, PartyPopper } from 'lucide-react';

export default function Step5Success() {
  return (
    <div className="flex flex-col items-center justify-center text-center space-y-6 my-12">
      <div className="relative">
        <PartyPopper className="absolute -top-8 -left-10 h-16 w-16 text-accent opacity-50 -rotate-12" />
        <CheckCircle className="h-24 w-24 text-green-500" />
         <PartyPopper className="absolute -bottom-8 -right-10 h-16 w-16 text-accent opacity-50 rotate-12" />
      </div>
      <h2 className="text-3xl font-headline font-bold text-primary">Application Submitted Successfully!</h2>
      <p className="max-w-prose text-muted-foreground">
        Thank you for submitting your application for a provisional certificate. Our administration team will now review your details and documents.
      </p>
      <p className="max-w-prose text-muted-foreground">
        The review process typically takes <strong>3-5 working days</strong>. You will be notified via email or phone once your certificate is ready for collection.
      </p>
    </div>
  );
}
