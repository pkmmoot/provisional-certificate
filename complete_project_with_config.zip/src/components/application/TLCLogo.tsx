import { cn } from '@/lib/utils';
import type { SVGProps } from 'react';

export function TLCLogo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 100 100"
      {...props}
      className={cn('fill-current', props.className)}
    >
      <title>Tinsukia Law College Logo</title>
      <circle cx="50" cy="50" r="48" stroke="currentColor" strokeWidth="4" fill="none" />
      <path d="M50 15 L25 35 L25 75 L50 95 L75 75 L75 35 Z" stroke="currentColor" strokeWidth="3" />
      <text x="50" y="60" textAnchor="middle" fontSize="30" fontWeight="bold" >
        TLC
      </text>
    </svg>
  );
}
